#include"SortAlg.h"
#include"ProgramFrame.h"
#include"SATest.h"
#include"SortArray.h"
void main() {
	SATest<float> sortTest(new InterchangeS<float>());
	sortTest.run(cin, cout);
	return;
}