#pragma once
#include"ProgramFrame.h"
#include"SortArray.h"
#include<vector>
template<class T>
class SATest : public ProgramFrame {
    SortArray<T>* mAlg;
    vector<T> Data;
public:
    SATest(SortArray<T>* pAlg) { mAlg = pAlg; }
    void Input(istream& is) {
        Data.clear();
        int n = 0;
        cout << "Nhap so phan tu: ";
        is >> n;
        for (int i = 0; i < n; i++)
        {
            cout << "Nhap phan tu thu " << i << ": ";
            T t;
            is >> t;
            Data.push_back(t);
        }
    }
    bool Check() { return Data.size() > 0; }
    void Output(ostream& os) {
        os << "Result after sorting : ";
        for (auto i : Data)
        {
            os << i << " ";
        }
    }
    void startMessage(ostream& os) {
        os << "Enter n, then a[0], ..., a[n - 1]: ";
    }
    void PROCESS() {
        if (mAlg != NULL) mAlg->process(Data);
    }
};