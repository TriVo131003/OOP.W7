#pragma once
#include "SortArray.h"
using namespace std;
template <class T>
class SelectionS :public SortArray<T>
{
public:
    void process(vector<T>& a) {
        int min = 0;
        for (int i = 0; i < a.size() - 1; i++) {
            min = i;
            for (int j = i + 1; j < a.size(); j++) {
                if (a[j] < a[min]) {
                    min = j;
                }
            }
            if (min != i) {
                swap(a[min], a[i]);
            }
        }
    };
};
template <class T>
class InsertionS :public SortArray<T>
{
public:
    void process(vector<T>& a)
    {
        int i, j;
        T key;
        for (i = 1; i < a.size(); i++)
        {
            key = a[i];
            j = i - 1;
            while (j >= 0 && a[j] > key)
            {
                a[j + 1] = a[j];
                j = j - 1;
            }
            a[j + 1] = key;
        }
    }
};
template <class T>
class InterchangeS :public SortArray<T>
{
public:
    void process(vector<T>& a) {
        for (int i = 0; i < a.size() - 1; i++)
            for (int j = i + 1; j < a.size(); j++)
                if (a[i] > a[j])
                    swap(a[i], a[j]);
    }
};