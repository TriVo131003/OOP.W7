#pragma once
#include <iostream>
using namespace std;
class ProgramFrame
{
protected:
    virtual void startMessage(ostream&);
    virtual void Input(istream&) = 0;
    virtual bool Check() = 0;
    virtual void errorMessage(ostream&);
    virtual void Output(ostream&) = 0;
    virtual void PROCESS() = 0;
    virtual bool Continue(istream&, ostream&);
public:
    void run(istream&, ostream&);
};