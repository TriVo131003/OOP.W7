#pragma once
#include<vector>
#include<iostream>
using namespace std;
template <class T>
class SortArray {
public:
    virtual void process(vector<T>& a) = 0;
};